<?php $__env->startSection('content'); ?>

        <?php if($category->products->isEmpty()): ?>
            <div class="block-head">
                <span class="line-left"></span>
                    <h2 class="text-mid">Пусто...</h2>
                <span class="line-right"></span>
            </div>
        <?php else: ?>
            <div class="block-head">
                <span class="line-left"></span>
                    <h2 class="text-mid"><?php echo e($category->name); ?></h2>
                <span class="line-right"></span>
            </div>
        <?php endif; ?>

        <div id="products">
            
            <?php $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <div class="product" style="height: 390px; width: 245px;">
                    <div class="price">
                        <span><?php echo e($product->price); ?></span>
                        <span>руб.</span>
                    </div>
                    <img src="<?php echo e(URL::asset('img/products/' . $product->img)); ?>" alt="<?php echo e($product->name); ?>">
                    <h3 style="height: 58px;"><?php echo e($product->name); ?></h3>
                    <div class="description">
                        <span><?php echo e($product->description); ?></span>
                    </div>
                    <div style=""  class="size">
                        <span><?php echo e($product->size . $product->unit); ?></span>
                    </div>
                    <div 
                        class="basket"
                        data-category="<?php echo e($category->name); ?>"
                        data-id="<?php echo e($product->id); ?>"
                        data-name="<?php echo e($product->name); ?>"
                        data-description="<?php echo e($product->description); ?>"
                        data-price="<?php echo e($product->price); ?>"
                        data-size="<?php echo e($product->size); ?>"
                        data-unit="<?php echo e($product->unit); ?>"
                        data-url=<?php echo e(route('add_to_cart')); ?>

                    >
                        <span>В корзину</span>
                    </div>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>