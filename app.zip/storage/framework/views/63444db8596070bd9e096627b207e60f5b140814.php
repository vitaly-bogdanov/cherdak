<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Сообщение с сайта "Чердак"</title>
    <style>
        table {
            border-collapse: collapse;
            border: 1px solid black;
        }
        td {
            padding: 5px;
            border: 1px solid black;
        }
        th {
            border: 1px solid black;
        }
        p {
            margin-top: 5px;
            margin-bottom: 5px;
        }
    </style>
</head>
<body>
    <p><strong>ID заказа: <?php echo e($id); ?></strong></p>
    <p>Имя заказчика: <?php echo e($name); ?></p>
    <p>Телефон: <a href="tel:<?php echo e($phone); ?>"><?php echo e($phone); ?></a></p>
    <p>Адрес: <?php echo e($adres); ?></p>
    <p>Сумма заказа: <?php echo e($tottal_price); ?> р.</p>
    <?php if($maney == 'cash'): ?> 
        <p>Способ оплаты: наличные</p>
        <?php if($back != 0): ?> 
            <p>Сдача с <?php echo e($back); ?> р.</p>
        <?php else: ?>
            <p>Без сдачи</p>
        <?php endif; ?>
    <?php elseif($maney == 'card'): ?>
        <p>Способ оплаты: карта</p>
    <?php endif; ?>

    <table>
        <tr>
            <th>Категория</th>
            <th>Наименование</th>
            <th>Цена за ед.</th>
            <th>Вес</th>
            <th>Количество</th>
        </tr>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($product['category']); ?></td>
                <td><?php echo e($product['name']); ?></td>
                <td><?php echo e($product['price']); ?>р.</td>
                <td><?php echo e($product['size'] . $product['unit']); ?></td>
                <td><?php echo e($product['count'] . 'ед'); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>
</html>