<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Пиццерия "Чердак"</title>

    <link rel="stylesheet" href="<?php echo e(URL::asset('css/main.min.css')); ?>"> 
</head>
<body>
    <header>
        <div id="top-line"></div>
        <div class="container">
            <div id="head">

                <div class="logo">
                    <img src="<?php echo e(URL::asset('img/logo.png')); ?>" alt="logo">
                </div>

                <div id="nav-bar">
                    <div id="top-contacts">
                        <span>+7(4212) 77-60-97</span>
                        <span>ул. Королёва, 2</span>
                    </div>
                    <nav>
                        <a class="link" href="#scroll-menu">Меню</a>
                        <span>|</span>
                        <a class="link" href="#s4">Доставка</a>
                        <span>|</span>
                        <a class="link" href="#bot-contacts">Контакты</a>
                    </nav>
                </div>

            </div>
        </div>
    </header>

    <section id="s1">
        <div class="container">
            <div id="banner" data-lelt="<?php echo e(URL::asset('img/pizza_left.png')); ?>" data-right="<?php echo e(URL::asset('img/pizza_right.png')); ?>">
                <div class="owl-carousel owl-theme">

                    <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e(URL::asset('img/banners/' . $banner->img)); ?>" alt="<?php echo e($banner->name); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                </div>
            </div>
        </div>
    </section>

    <section id="s2">
        <div class="container">
            <div id="menu">
                <div class="block-head">
                    <span class="line-left"></span>
                    <h2 id="scroll-menu" class="text-mid">Меню</h2>
                    <span class="line-right"></span>
                </div>

                <div id="menu-btn">
                    <p id="open_menu">
                        Показать всё
                    </p>
                    <div id="links">

                        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="ajax-link link link" href="<?php echo e(route('choice', ['id' => $item->id])); ?>" data-href="<?php echo e(route('ajax_cart', $item->id)); ?>">
                                <span><?php echo e($item->name); ?></span>
                            </a> <br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>

                <div id="choice">

                    <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="ajax-link element-menu" href="<?php echo e(route('choice', ['id' => $item->id])); ?>" data-href="<?php echo e(route('ajax_cart', $item->id)); ?>">
                            <span><?php echo e($item->name); ?></span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

            </div>
        </div>
    </section>

    <section id="s3">
        <div class="container">
            <div id="content">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </section>


    <section id="s4">
        <div class="container">
            <div id="delivery">
                <div class="block-head">
                    <span class="line-left"></span>
                    <h2 class="text-mid">Доставка</h2>
                    <span class="line-right"></span>
                </div>
                <div id="terms">
                    <h4>Условия доставки</h4>
                    <p>Мы обслуживаем ограниченную территорию города. Стоимость доставки 150 рублей. Уточнить возможность доставки на интересующий Вас адрес можно по карте города. Ну и конечно, заказ можно забрать самостоятельно (это дешевле).</p>
                    <p>Заказ можно будет оплатить наличными или банковской картой при получении. В случае оплаты наличными указывайте необходимость в сдаче, и с какой суммы.</p>
                    <p>Время доставки зависит от загруженности кухни и дорожной обстановки в городе на момент доставки. Среднее время доставки - 45 минут с момента оформления заказа. Если заявка делается на определенное время, погрешность при доставке составляет ±30 минут.</p>
                    <p>Мы принимаем заказы ежедневно с 10 до 22 часов. Заявки, поступившие в нерабочие часы пиццерии, будут обработаны не сразу. При заказе на сайте - наш менеджер свяжется с Вами по указанному в заявке номеру телефона для подтверждения заказа. Заказ будет принят в работу только после подтверждения Вами заказа.</p>
                </div>
            </div>
        </div>
    </section>

    <section id="s5">
        <div class="container">
            <div id="map">
                <div class="block-head">
                    <span class="line-left"></span>
                    <h2 class="text-mid">Территория доставки</h2>
                    <span class="line-right"></span>
                </div>
                <iframe src="https://yandex.ru/map-widget/v1/-/CBRyUWFwGA" width="100%" height="660" framebordr="1" allowfullscreen="true"></iframe>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div id="foot">
                <div class="logo">
                    <img src="<?php echo e(URL::asset('img/logo.png')); ?>" alt="logo">
                </div>

                <div id="bot-contacts">
                    <p>+7 (4212) 77-60-97</p>
                    <p><a href="mailto:cherdak.khv@bk.ru">Cherdak.khv@bk.ru</a></p>
                    <p>143005, г. Хабаровск, <br> ул. Королёва, 2 (2 этаж)</p>
                </div>
                
                <div id="work">
                    <p>Режим работы доставки: <br> пн-чт - 11:00 до 23:00 <br> пт - 11:00 до 01:00 <br> сб - 12:00 до 01:00 <br> вскр - 12:00 до 23:00</p>
                    <p>График работы кафе: <br> пн-чт - 11:00 до 23:00 <br> пт - 11:00 до 01:00 <br> сб - 12:00 до 01:00 <br> вскр - 12:00 до 23:00</p>
                </div>
            </div>
        </div>
        <div id="bot-line">
            <span>© 2018 Пиццерия «Чердак»</span> 
            <span>ИП Шамшин Антон Васильевич</span> 
            <span>ИНН-272316491334</span>
        </div>
    </footer>

    <div id="overlay">
    
    </div>

    <div id="basket">
        <div id="buy">
            <div id="block">
                <div class="close">X</div>
                <p id="head-basket">Корзина</p>
                <div id="ordered_goods">
                    
                </div>
            </div>
        </div>
    </div>

    <div id="border1">
        <div id="border2">
            <div id="win">
                <div class="close">X</div>
                <form id="sent-request" action="<?php echo e(route('sent_cart')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <p class="request-head">Оставьте заявку</p>
                    <input type="text" name="name" placeholder="Имя*" required>
                    <input type="text" name="phone" placeholder="Телефон*" required>
                    <input type="text" name="adres" placeholder="Адрес*" required>
                    <p class="request-head mrg-fix">Способ оплаты</p>

                    <input type="radio" name="cash" value="cash" id="cash1" checked>
                    <label for="cash1">Наличные</label> <br>

                    <input type="radio" name="cash" value="card" id="cash2">
                    <label for="cash2">Карта</label> <br>

                    <div id="ifcash">
                        <input type="radio" name="manyback" value="no" id="cash3" checked>
                        <label for="cash3">Без сдачи</label> <br>
        
                        <input type="radio" name="manyback" value="yes" id="cash4">
                        <label for="cash4"><span>Сдача с</span><input maxlength="4" name="sum" class="many" type="text"><span>руб.</span></label> <br>
                    </div>

                    <p id="conf">Нажимая кнопку «оформить заказ» я соглашаюсь с обработкой моих персональных данных в соответствии с <a href="">политикой конфиденциальности</a>.</p>

                    <input style="outline: none;" type="submit" value="Отправить">

                </form>
            </div>
        </div>
    </div>

    <div id="fixed-basket" style="z-index: 999;" data-url="<?php echo e(route('view_cart')); ?>">
        <img src="<?php echo e(URL::asset('img/cart.png')); ?>" alt="cart">
        <div id="count">
            <span>0</span>
        </div>
    </div>

    <script src="<?php echo e(URL::asset('js/libs.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('js/common.min.js')); ?>"></script>
</body>
</html>